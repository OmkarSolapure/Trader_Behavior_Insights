# Trader_Behaviour_Insights

A Python project to analyze trader behaviour with historical data and Fear/Greed index.

## Structure
- outputs/: CSV results
- figures/: charts
- report/: markdown reports

## Run
```bash
python Trader_Behavior_Insights.py
```
