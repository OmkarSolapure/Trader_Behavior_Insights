import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.pagesizes import A4

INPUT_HISTORICAL = "historical_data.csv"
INPUT_FEAR_GREED = "fear_greed_index.csv"
OUTPUT_DIR = "outputs"
FIG_DIR = "figures"
REPORT_DIR = "report"

os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(FIG_DIR, exist_ok=True)
os.makedirs(REPORT_DIR, exist_ok=True)


def load_data(hist_file, fg_file):
    df_hist = pd.read_csv(hist_file)
    df_fg = pd.read_csv(fg_file)

    df_hist.columns = df_hist.columns.str.strip().str.lower()
    df_fg.columns = df_fg.columns.str.strip().str.lower()

    # Parse historical timestamp
    if "timestamp ist" in df_hist.columns:
        df_hist["__day"] = pd.to_datetime(
            df_hist["timestamp ist"], format="%d-%m-%Y %H:%M", errors="coerce"
        ).dt.date
    elif "timestamp" in df_hist.columns:
        df_hist["__day"] = pd.to_datetime(df_hist["timestamp"], errors="coerce").dt.date
    else:
        raise KeyError("No timestamp column found in historical_data.csv")

    # Parse fear & greed date
    if "date" in df_fg.columns:
        df_fg["__day"] = pd.to_datetime(df_fg["date"], errors="coerce").dt.date
    else:
        raise KeyError("No date column found in fear_greed_index.csv")

    # Rename for consistency
    df_fg = df_fg.rename(
        columns={"value": "fear_greed_score", "classification": "fear_greed_class"}
    )

    fg_cols = ["__day", "fear_greed_class", "fear_greed_score"]
    df = df_hist.merge(df_fg[fg_cols], on="__day", how="left")

    return df, df_hist, df_fg


def analyze(df):
    results = {}

    if "closed pnl" in df.columns:
        df["closed pnl"] = pd.to_numeric(df["closed pnl"], errors="coerce")
        results["mean_pnl"] = df["closed pnl"].mean()
        results["std_pnl"] = df["closed pnl"].std()
        results["min_pnl"] = df["closed pnl"].min()
        results["max_pnl"] = df["closed pnl"].max()

    if "fear_greed_class" in df.columns:
        results["class_counts"] = df["fear_greed_class"].value_counts().to_dict()

    return results


def save_figures(df):
    # PnL Over Time
    if "closed pnl" in df.columns:
        plt.figure(figsize=(10, 5))
        df.groupby("__day")["closed pnl"].sum().plot(title="PnL Over Time")
        plt.ylabel("Closed PnL")
        plt.savefig(os.path.join(FIG_DIR, "pnl_over_time.png"))
        plt.close()

    # Fear & Greed Score Over Time
    if "fear_greed_score" in df.columns:
        plt.figure(figsize=(10, 5))
        df.groupby("__day")["fear_greed_score"].mean().plot(title="Fear & Greed Over Time")
        plt.ylabel("Fear & Greed Score")
        plt.savefig(os.path.join(FIG_DIR, "fear_greed_score.png"))
        plt.close()

    # PnL Distribution
    if "closed pnl" in df.columns:
        plt.figure(figsize=(8, 5))
        df["closed pnl"].dropna().hist(bins=30)
        plt.title("PnL Distribution")
        plt.xlabel("Closed PnL")
        plt.ylabel("Frequency")
        plt.savefig(os.path.join(FIG_DIR, "pnl_distribution.png"))
        plt.close()

    # Fear & Greed Class Distribution
    if "fear_greed_class" in df.columns:
        plt.figure(figsize=(8, 5))
        df["fear_greed_class"].value_counts().plot(kind="bar", title="Fear & Greed Class Distribution")
        plt.ylabel("Count")
        plt.savefig(os.path.join(FIG_DIR, "fear_greed_class_distribution.png"))
        plt.close()


def create_pdf_report(results):
    pdf_path = os.path.join(REPORT_DIR, "analysis_report.pdf")
    doc = SimpleDocTemplate(pdf_path, pagesize=A4)
    styles = getSampleStyleSheet()
    story = []

    story.append(Paragraph("<b>Trading Analysis Report</b>", styles["Title"]))
    story.append(Spacer(1, 20))

    # Summary stats
    if "mean_pnl" in results:
        story.append(Paragraph("<b>Summary Statistics (Closed PnL)</b>", styles["Heading2"]))
        stats_text = f"""
        Mean PnL: {results['mean_pnl']:.2f}<br/>
        Std Dev PnL: {results['std_pnl']:.2f}<br/>
        Min PnL: {results['min_pnl']:.2f}<br/>
        Max PnL: {results['max_pnl']:.2f}<br/>
        """
        story.append(Paragraph(stats_text, styles["Normal"]))
        story.append(Spacer(1, 20))

    # Fear & Greed class counts
    if "class_counts" in results:
        story.append(Paragraph("<b>Fear & Greed Class Distribution</b>", styles["Heading2"]))
        for k, v in results["class_counts"].items():
            story.append(Paragraph(f"{k}: {v}", styles["Normal"]))
        story.append(Spacer(1, 20))

    # Add Figures
    for fig_file in ["pnl_over_time.png", "fear_greed_score.png",
                     "pnl_distribution.png", "fear_greed_class_distribution.png"]:
        fig_path = os.path.join(FIG_DIR, fig_file)
        if os.path.exists(fig_path):
            story.append(Image(fig_path, width=400, height=250))
            story.append(Spacer(1, 20))

    doc.build(story)
    print(f"PDF report saved at {pdf_path}")


def main():
    print("Starting analysis...")
    df, hist, fg = load_data(INPUT_HISTORICAL, INPUT_FEAR_GREED)
    results = analyze(df)

    # Save merged and summary
    df.to_csv(os.path.join(OUTPUT_DIR, "merged_data.csv"), index=False)
    pd.DataFrame([results]).to_csv(os.path.join(OUTPUT_DIR, "summary.csv"), index=False)

    # Save figures + report
    save_figures(df)
    create_pdf_report(results)

    print("Analysis complete. Check outputs/, figures/, and report/.")


if __name__ == "__main__":
    main()
